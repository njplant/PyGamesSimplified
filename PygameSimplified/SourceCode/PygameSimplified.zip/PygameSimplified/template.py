#part 1: initialise pygame
import pygame
pygame.init()

#part 2: make importations
from PygameSimplified.World import*
from PygameSimplified.Actor import*
from PygameSimplified.Event import*
from PygameSimplified.Text import*

#part 3: run code inside the while loop 
while True:
	Event.update()
	
	#part 4 : events, if user clicks X quit game 
	if Event.contains("exit"):
		Event.quit_game()

#Author Fatima Abukar
#A facade class for all the Pygame Simplified imports

import pygame
from pygame import *
import sys

import PGS.Actor
import PGS.World
import PGS.Text
import PGS.Event
import PGS.Timer
import PGS.Sound


from PGS.Actor import Actor
from PGS.World import World
from PGS.Text import Text
from PGS.Event import Event
from PGS.Timer import Timer
from PGS.Sound import Sound



